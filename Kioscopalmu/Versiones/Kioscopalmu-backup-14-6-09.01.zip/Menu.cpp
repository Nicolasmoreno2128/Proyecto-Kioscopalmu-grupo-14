#include <iostream>
#include "Menu.h"
using namespace std;

void mostrarMenuPrincipal() {
    int opcion;
    do {
        cout << "\n===== MENU PRINCIPAL =====" << endl;
        cout << "1. Productos" << endl;
        cout << "2. Proveedores" << endl;
        cout << "3. Compras" << endl;
        cout << "0. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1: menuProductos(); break;
            case 2: menuProveedores(); break;
            case 3: menuCompras(); break;
            case 0: cout << "Saliendo del programa." << endl; break;
            default: cout << "Opcion invalida. Intente nuevamente.\n"; break;
        }
    } while(opcion != 0);
}

// PRODUCTOS
void menuProductos() {
    int opcion;
    do {
        cout << "\n--- MENU PRODUCTOS ---" << endl;
        cout << "1. Alta de producto" << endl;
        cout << "2. Listar productos" << endl;
        cout << "0. Volver al menu principal" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1: altaProducto(); break;
            case 2: listarProductos(); break;
            case 0: break;
            default: cout << "Opcion invalida.\n"; break;
        }
    } while(opcion != 0);
}

void altaProducto() {
    cout << ">> Aqui se ejecutaria la funcion para dar de alta un producto." << endl;
}

void listarProductos() {
    cout << ">> Aqui se ejecutaria la funcion para listar productos." << endl;
}

// PROVEEDORES
void menuProveedores() {
    int opcion;
    do {
        cout << "\n--- MENU PROVEEDORES ---" << endl;
        cout << "1. Alta de proveedor" << endl;
        cout << "2. Listar proveedores" << endl;
        cout << "0. Volver al menu principal" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1: altaProveedor(); break;
            case 2: listarProveedores(); break;
            case 0: break;
            default: cout << "Opcion invalida.\n"; break;
        }
    } while(opcion != 0);
}

void altaProveedor() {
    cout << ">> Aqui se ejecutaria la funcion para dar de alta un proveedor." << endl;
}

void listarProveedores() {
    cout << ">> Aqui se ejecutaria la funcion para listar proveedores." << endl;
}

// COMPRAS
void menuCompras() {
    int opcion;
    do {
        cout << "\n--- MENU COMPRAS ---" << endl;
        cout << "1. Registrar compra" << endl;
        cout << "2. Listar compras" << endl;
        cout << "0. Volver al menu principal" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1: registrarCompra(); break;
            case 2: listarCompras(); break;
            case 0: break;
            default: cout << "Opcion invalida.\n"; break;
        }
    } while(opcion != 0);
}

void registrarCompra() {
    cout << ">> Aqui se ejecutaria la funcion para registrar una compra." << endl;
}

void listarCompras() {
    cout << ">> Aqui se ejecutaria la funcion para listar compras." << endl;
}
