#ifndef MENU_H
#define MENU_H

void mostrarMenuPrincipal();

void menuTipoProducto();
void agregarTipoProducto();
void listarTipoProductos();

void menuProductos();
void altaProducto();
void listarProductos();
void buscarProductos();
void cantidadProductos();

void menuProveedor();
void altaProveedor();
void listarProveedores();
void buscarProveedoresDNI();
void buscarProveedoresCUIT();
void CantidadProveedores();

void menuCompras();
void registrarCompra();
void listarCompras();

#endif // MENU_H
