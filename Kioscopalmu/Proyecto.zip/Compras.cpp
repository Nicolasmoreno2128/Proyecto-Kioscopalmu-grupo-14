#include <iostream>
#include <cstdlib>
#include "FuncionesGlobales.h"
#include "Compras.h"
#include <cstring>

using namespace std;
#include "Fecha.h"
#include "ArchivoCompras.h"

// Constructor por defecto
Compras::Compras() {
    idCompra = 0;
    nroProducto = 0;
    strcpy(CUITproveedor,"" );
    fecha = Fecha(1,1,2025); // Fecha por defecto
    cantidad = 0;
    importe = 0.0;
}

// Constructor con par�metros
Compras::Compras(int _idCompra, int _nroProducto, const char* _CUITproveedor, Fecha _fecha, int _cantidad, float _importe) {
    idCompra = _idCompra;
    nroProducto = _nroProducto;
    strcpy(CUITproveedor, _CUITproveedor);
    fecha = _fecha;
    cantidad = _cantidad;
    importe = _importe;
}

// M�todos getter
int Compras::getIdCompra() {
    return idCompra;
}

int Compras::getNroProducto() {
    return nroProducto;
}

const char* Compras::getCUITproveedor() {
    return CUITproveedor;
}

Fecha Compras::getFecha() {
    return fecha;
}

int Compras::getCantidad() {
    return cantidad;
}

float Compras::getImporte() {
    return importe;
}

// M�todos setter
void Compras::setIdCompra(int _idCompra) {
    idCompra = _idCompra;
}

void Compras::setNroProducto(int _nroProducto) {
    nroProducto = _nroProducto;
}

void Compras::setCUITproveedor(const char* _CUITproveedor) {
   strcpy(CUITproveedor, _CUITproveedor);
}

void Compras::setFecha(Fecha _fecha) {
    fecha = _fecha;
}

void Compras::setCantidad(int _cantidad) {
    cantidad = _cantidad;
}

void Compras::setImporte(float _importe) {
    importe = _importe;
}

// M�todo para cargar datos
void Compras::cargar() {
    cout << "ID COMPRA: ";
    cin >> idCompra;
    cout << "NUMERO DE PRODUCTO: ";
    cin >> nroProducto;
    cout << "CUIT PROVEEDOR: ";
    cargarCadena(CUITproveedor, 49);
    cout << "FECHA DE COMPRA:" << endl;
    fecha.Cargar();
    cout << "CANTIDAD: ";
    cin >> cantidad;
    cout << "IMPORTE: ";
    cin >> importe;
}

// M�todo para mostrar datos
void Compras::mostrar() {
    cout << "ID Compra: " << idCompra << endl;
    cout << "Numero de Producto: " << nroProducto << endl;
    cout << "CUIT Proveedor: " << CUITproveedor << endl;
    cout << "Fecha: ";
    fecha.Mostrar();
    cout << "Cantidad: " << cantidad << endl;
    cout << "Importe: $" << importe << endl;
}
// Metodos del menu
void registrarCompra() {
    ArchivoCompras archivo("compras.dat");
    Compras compra;
    compra.cargar();

    if(archivo.Guardar(compra)) {
        cout << "Compra guardada correctamente!" << endl;
                                }
    else {
        cout << "Error al guardar!" << endl;
        }
}
void listarCompras() {

    ArchivoCompras archivo("compras.dat");
    int cantidad = archivo.CantidadRegistros();
        cout << "Cantidad de compras: " << cantidad << endl;

        if(cantidad > 0) {
            Compras *compras = new Compras[cantidad];
            archivo.Leer(cantidad, compras);

        for(int i = 0; i < cantidad; i++) {
                cout << "\n--- Registro " << i+1 << " ---" << endl;
                compras[i].mostrar();
                                            }
            delete[] compras;
                            }

}
void buscarxIDcompra(){

    ArchivoCompras archivo("compras.dat");
    int id;
        cout << "ID de compra a buscar: ";
        cin >> id;

        int pos = archivo.Buscar(id);
            if(pos != -1) {
            Compras compra = archivo.Leer(pos);
            cout << "Encontrada en posicion " << pos << ":" << endl;
            compra.mostrar();
            } else {
            cout << "No encontrada!" << endl;
                    }
}
void buscarProducto(){
    ArchivoCompras archivo("compras.dat");
    int nroProd;
        cout << "Numero de producto a buscar: ";
        cin >> nroProd;

            int pos = archivo.BuscarPorProducto(nroProd);
            if(pos != -1) {
                Compras compra = archivo.Leer(pos);
                cout << "Encontrada en posicion " << pos << ":" << endl;
                    compra.mostrar();
            } else {
                cout << "No encontrada!" << endl;
                    }
}
void buscarProveedorcomp(){
    ArchivoCompras archivo("compras.dat");
     char cuit[25];
        cout << "CUIT de proveedor a buscar: ";
        cargarCadena(cuit,25);

        int pos = archivo.BuscarPorProveedor(cuit);
            if(pos != -1) {
                Compras compra = archivo.Leer(pos);
                    cout << "Encontrada en posicion " << pos << ":" << endl;
                    compra.mostrar();
                    }
            else { cout << "No encontrada!" << endl;
                  }
}
void Cantidadregistroscomp(){
    ArchivoCompras archivo("compras.dat");
        cout << "Cantidad de registros: " << archivo.CantidadRegistros() << endl;
}
