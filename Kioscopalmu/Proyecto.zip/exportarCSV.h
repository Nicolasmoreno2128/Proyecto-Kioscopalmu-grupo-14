#ifndef EXPORTARCSV_H_INCLUDED
#define EXPORTARCSV_H_INCLUDED

int exportarExcelCompras();
int exportarExcelProveedores();
int exportarExcelTipoProductos();
int exportarExcelProductos();


#endif // EXPORTARCSV_H_INCLUDED
